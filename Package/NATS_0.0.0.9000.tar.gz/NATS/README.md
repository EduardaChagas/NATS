# NATS_package
package repository NATS - non-parametric analysis of time series
